package graphs;


/**
 * Implement the Digraph.java interface in
 * the Digraph.java class using an adjacency list
 * data structure to represent directed graphs.
 */
public class Digraph {


    public Digraph(int V) {
        // TODO
    }

    /**
     * The number of vertices
     */
    public int V() {
        // TODO
         return -1;
    }

    /**
     * The number of edges
     */
    public int E() {
        // TODO
         return -1;
    }

    /**
     * Add the edge v->w
     */
    public void addEdge(int v, int w) {
        // TODO
    }

    /**
     * The nodes adjacent to node v
     * that is the nodes w such that there is an edge v->w
     */
    public Iterable<Integer> adj(int v) {
        // TODO
         return null;
    }

    /**
     * A copy of the digraph with all edges reversed
     */
    public Digraph reverse() {
        // TODO
         return null;
    }

}
